/*
PROJECT 1 - Six-Function Calculator
Below each comment you see, write code that satisfies its instructions.
When finished, compress this project  into a ZIP folder and submit it to Canvas.
You MUST build and run your code in RELEASE mode to receive full credit.
*/

#include <iostream>
//Add the cmath library to main.cpp. (4)
#include <cmath>

using namespace std;

int main(){
    int x, y, operation;
    //x and y represent the operands of the selected calculation.
    //Prompt the user to enter whole number values for these variables.
    //Your prompt should include two cout or printf calls to explain the required input
    //and matching cin calls. (8)
    cout<< "Enter a value for x " << endl;
    cin>> x;
    cout<< "Enter a value for y " << endl;
    cin>> y;

    cout<< "Available Operations:\n\
            1 - Addition\n\
            2 - Subtraction\n\
            3 - Multiplication\n\
            4 - Division (Quotient)\n\
            5 - Division (Remainder)\n\
            6 - Exponentiation\n\
            Make a selection: ";

    //operation represents the selected arithmetic function to perform.
    //Create a cin call to take input for operation. (2)
    cin>> operation;

    //Create a switch statement to select and perform calculations based on input for operation.
    //Cases 1, 2, 3, and 6 should perform their calculation with no error checking.
    //Cases 4 and 5 should check if y is equal to zero.
    //If it is, print an error and do not attempt to perform the operation.
    //Include a default case that notifies the user of an invalid input.
    //Each case is worth 8 points. The switch block itself is worth 10 points.
    switch(operation){
        case 1:
            cout<< x+y << endl;
            break;
        case 2:
            cout<< x-y << endl;
            break;
        case 3:
            cout<< x*y << endl;
            break;
        case 4:
            cout<< x/y << endl;
            break;
        case 5:
            cout<< x%y << endl;
            break;
        case 6:
            cout<< pow(x,y) << endl;
            break;
        default:
            cout<< "Error Invalid Input!" << endl;
            break;
        }

    return 0;
}
